#ifndef QUEUE_H
#define QUEUE_H

#include <k/kstd.h>
#include <k/types.h>

#include "multiboot.h"
#include "io.h"

// Queue || FIFO

struct queue {
        u8 content[10];
        size_t head;
        size_t tail;
        size_t size;
        size_t size_max;
};

static struct queue queue;

void init_queue(void);
int inqueue(u8 value);
int dequeue(u8 *value);

#endif /*QUEUE_H*/
