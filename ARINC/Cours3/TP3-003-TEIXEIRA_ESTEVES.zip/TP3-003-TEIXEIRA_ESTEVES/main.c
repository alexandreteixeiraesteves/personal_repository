#include "complex_vectors_c/complex_vectors.h"

void main() {
	Complex_vectors__vectors_out o;
	for(;;) {
		Complex_vectors__vectors_step(&o);
	}
}
