#ifndef LEVEL_H
#define LEVEL_H

uint32_t read_level() ;

#endif
