#ifndef COMPLEX_IO_TYPES_H
#define COMPLEX_IO_TYPES_H

#include "complex_c/complex_types.h"

//typedef struct { struct Complex__complex o; } Complex_io__read_complex_out ;
//typedef struct { } Complex_io__print_complex_out ;

#endif // COMPLEX_IO_TYPES_H
