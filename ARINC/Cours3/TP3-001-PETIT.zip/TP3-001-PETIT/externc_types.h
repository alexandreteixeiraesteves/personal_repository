#ifndef EXE
#define EXE
#include "externc.h"
#endif
