#ifndef TWIDDLE_INIT_H
#define TWIDDLE_INIT_H
#include "complex.h"
#include <math.h>

void init_twiddle1024(Complex__complex* twiddle) ;

#endif //TWIDDLE_INIT_H
