#include "timer.h"

void init_tick(void){
	tick = 0;
	devider = 1193182/100;
	outb(CTRL_REG, 0b10000100);
	outb(COUNT0, (u8)devider);
}

unsigned long gettick(void){
	return tick;
}

void update_tick(void){
	tick++;
}
