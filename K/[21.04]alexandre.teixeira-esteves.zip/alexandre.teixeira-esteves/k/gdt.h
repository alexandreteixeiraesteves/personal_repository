#ifndef GDT_H
#define GDT_H

#include <k/kstd.h>
#include <k/types.h>

#include "multiboot.h"
#include "io.h"
#include "gdtr.h"

// GDT = tableau de segment 

struct __attribute__((packed)) segment {
	u64 seg_lim		 :16;	// Segment Limit	00:15	
	u64 base_addr		 :16;	// Base adress 		16:31
	u64 base1		 : 8;	// Base			32:39
	u64 type 		 : 4; 	// 4 bits - access 		// Type 		40:43
	u64 s 			 : 1; 	// 1 bit			// s			44:44
	u64 dpl 		 : 2;	// 2 bits 			// dpl			45:46
	u64 p 		 	 : 1; 	// 1 bit			// p			47:47
	u64 seg_lim_bis 	 : 4; 	// 4 bits			// Segment limite (2) 	48:51
	u64 avl 		 : 1;	// 1 bit - reserved for me 	// AVL			52:52
	u64 l 		 	 : 1;	// 1 bit			// L			53:53
	u64 d_b 		 : 1;	// 1 bit			// D/B			54:54
	u64 g 		 	 : 1;	// 1 bit			// G			55:55
	u64 base2		 : 8;	// Base			56:63
};

struct segment segment_create(u64 seg_lim,
        	u64 base_addr,
        	u64 base1,
        	u64 type,
        	u64 s,           
        	u64 dpl,          
        	u64 p,             
        	u64 seg_lim_bis,    
        	u64 avl,            
        	u64 l,              
        	u64 d_b,           
        	u64 g,              
        	u64 base2);

void init_gdt(void);

static struct segment gdt[6];
static struct gdt_r gdtr;


#endif /*GDT_H*/
