#ifndef PIC_H
#define PIC_H

#include <k/kstd.h>
#include <k/types.h>

#include "io.h"

#define A_MSTR 0x20 // PIC MASTER port A
#define B_MSTR 0x21 // PIC MASTER port B
#define A_SLVE 0xA0 // PIC SLAVE port A
#define B_SLVE 0xA1 // PIC SLAVE port B

// PIC = Programmable Interrupt Controller

void init_pic(void);

#endif /*PIC_H*/                      
