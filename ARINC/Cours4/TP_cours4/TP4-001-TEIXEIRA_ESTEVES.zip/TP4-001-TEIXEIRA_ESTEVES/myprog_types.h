#ifndef MYPROG_TYPES_H
#define MYPROG_TYPES_H

#endif
