#include "gdt.h"

struct segment segment_create(u64 seg_lim,
                u64 base_addr,
                u64 base1,
                u64 type,
                u64 s,
                u64 dpl,
                u64 p,
                u64 seg_lim_bis,
                u64 avl,
                u64 l,
                u64 d_b,
                u64 g,
                u64 base2) {
	struct segment result;
	
	result.seg_lim = seg_lim ;
	result.base_addr = base_addr;
	result.base1 = base1;
	result.type = type;
	result.s = s;
	result.dpl = dpl;
	result.p = p;
	result.seg_lim_bis = seg_lim_bis;
	result.avl = avl;
	result.l = l;
	result.d_b = d_b;
	result.g = g;
	result.base2 = base2;

	return result;
}

// initialisation of the GDT
void init_gdt(void){

	// Null segment

	struct segment null_seg = segment_create(0x0000,
						0x0000,
						0b00000000,
						0b0000,
						0b0,
						0b00,
						0b0,
						0b0000,
						0b0,
						0b0,
						0b0,
						0b0,
						0b00000000
						);

	// Kernel Code segment

	struct segment kc_seg = segment_create(	0xFFFF,
                                                0x0000,
                                                0b00000000,
                                                0b1010,
                                                0b1,
                                                0b00,   // 00 kernel & 11 user 
                                                0b1,
                                                0b1111, // maybe 1111
                                                0b1,
                                                0b0,	//L 64 (1) or compatible (0)
                                                0b1,
                                                0b1,	// 1 car sinon peux pas acceder à tout l'adressage
                                                0b00000000
                                                );

	// Kernel Data segment

	struct segment kd_seg = segment_create(	0xFFFF,
                                                0x0000,
                                                0b00000000,
                                                0b0010,
                                                0b1,
                                                0b00,
                                                0b1,
                                                0b0000,
                                                0b1,
                                                0b0,
                                                0b1,
                                                0b1,
                                                0b00000000
                                                );


	// Userland Code segment //TODO at the end of the project

	struct segment uc_seg = segment_create(	0x0000,
                                                0x0000,
                                                0b00000000,
                                                0b0000,
                                                0b0,
                                                0b00,
                                                0b0,
                                                0b0000,
                                                0b0,
                                                0b0,
                                                0b0,
                                                0b0,
                                                0b00000000
                                                );


	// Userland Data segment //TODO at the end of the project

	struct segment ud_seg = segment_create(	0x0000,
                                                0x0000,
                                                0b00000000,
                                                0b0000,
                                                0b0,
                                                0b00,
                                                0b0,
                                                0b0000,
                                                0b0,
                                                0b0,
                                                0b0,
                                                0b0,
                                                0b00000000
                                                );

	// Task State Segment (don’t worry about that right now) //TODO at the end of teh project

	const struct segment ts_seg = segment_create(		0x0000,
                                                0x0000,
                                                0b00000000,
                                                0b0000,
                                                0b0,
                                                0b00,
                                                0b0,
                                                0b0000,
                                                0b0,
                                                0b0,
                                                0b0,
                                                0b0,
                                                0b00000000
                                                );


	// GDT is a table of segment

    gdt[0] = null_seg;
    gdt[1] = kc_seg;
    gdt[2] = kd_seg;
    gdt[3] = uc_seg;
    gdt[4] = ud_seg;
    gdt[5] = ts_seg;

	gdtr.base = (u32)gdt;
	gdtr.limit = sizeof(gdt);

	asm volatile("lgdt %0\r\n"
			: // no output
			:"m" (gdtr)
			:"memory");
	
}
