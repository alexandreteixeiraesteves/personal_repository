#include "idt.h"


/*
 * 	ASM function
 */

extern void isr_keyboard(void);
extern void isr_zero(void);
extern void isr_pit(void);

/*
 *handler function & generic handler
 */
void keyboard_interupt(void){
	u8 tmp;
	u8 ksr = inb(0x64);
	while ((ksr & 0b00000001) != 0b00000000) // test KSR
	{
		tmp = inb(0x60);  // I/O buffer of the keyboard
		if((tmp & 0b10000000) == 0b00000000) {
			inqueue(tmp);
			printf("Value capted was %x.\n",tmp);
		}
		ksr = inb(0x64);
	}
	outb(A_MSTR, 0b00100000); // end of interupt
}

/*
 * GETKEY---------------------------------
 */

int getkey(void){
	u8 tmp;
	int res = dequeue(&tmp);
	if(res != -1)
		res = (int)tmp;
	return res;
}

void generic_c_handler(struct stack stack){ 

	//printf("%d \r\n \r\n \r\n", stack.num_interupt);
	//asm volatile("xchg %bx, %bx\r\n");
	
	switch (stack.num_interupt){
		case 0 : 
			printf("Interuption 0\n");
			break;
		case 32 :
                        //printf("Interuption 32\n");
                        update_tick();
			unsigned long tmp = gettick();
                        printf("Interuption 32 with tick %ld\n",tmp );
			outb(A_MSTR, 0b00100000); // end of interupt
			break;
		case 33 :
			printf("Interuption 33\n");
			keyboard_interupt();
			break;
		default :
			printf("Unknown Interuption\n");
	}
}

/*
 *	Initialisation of the IDT
 */


static struct gate idt[255]; 	// 0 to 32 not free and maximum index can be 254
static struct idt_r idtr;

void init_idt(void){
	

	
	// keyboard gate

	u32 key_addr = (u32)isr_keyboard;
	
	u16 key_addr_high = 0b0;	// 16 bits de poid fort 
	u16 key_addr_low = 0b0;		// 16 bits de poid faible 

	key_addr_low = key_addr;
	key_addr_high = key_addr >> 16; 

	struct gate gate_keyboard = {
		.offset_low = key_addr_low,
		.seg_selct = 0x08,
		//.undefined = 0b00000,
		.nul  = 0b000,
		.g_type  = 0b01110,
		.dpl  = 0b00,
		.p  = 0b1,
		.offset_high = key_addr_high
	};
	
	idt[65] = gate_keyboard;

	 // nul_div zero gate

        u32 zero_addr = (u32)isr_zero;

        u16 zero_addr_high = 0b0;           // 16 bits de poid fort
        u16 zero_addr_low = 0b0;           // 16 bits de poid faible

        zero_addr_low = zero_addr;
        zero_addr_high = zero_addr >> 16;

        struct gate gate_zero = {
                .offset_low = zero_addr_low,
                .seg_selct = 0x08,
                //.undefined = 0b00000,
                .nul  = 0b000,
                .g_type  = 0b01110,
                .dpl  = 0b00,
                .p  = 0b1,
                .offset_high = zero_addr_high
        };
	
	idt[0] = gate_zero;

	// pit_gate timer interuption gate
	u32 pit_addr = (u32)isr_pit;

        u16 pit_addr_high = 0b0;           // 16 bits de poid fort
        u16 pit_addr_low = 0b0;           // 16 bits de poid faible

        pit_addr_low = pit_addr;
        pit_addr_high = pit_addr >> 16;

        struct gate gate_pit = {
                .offset_low = pit_addr_low,
                .seg_selct = 0x08,
                //.undefined = 0b00000,
                .nul  = 0b000,
                .g_type  = 0b01110,
                .dpl  = 0b00,
                .p  = 0b1,
                .offset_high = pit_addr_high
        };

        idt[64] = gate_pit;
/*
	// Defining of the Interupt Gate  (custom toujours interrupt)
	
	struct gate inter_gate;
	inter_gate.offset_b 	= ;
	inter_gate.seg_selct 	= ;
	inter_gate.undefined 	= 0b00000;
	inter_gate.nul 		= 0b000 ;
	inter_gate.g_type 	= 0b01110;
	inter_gate.dpl 		= 0b00;
	inter_gate.p 		= ;
	inter_gate.offset_e 	= ;


	// Defining of the Trap Gate
	

	struct gate trap_gate;
	trap_gate.offset_b 	= ;
	trap_gate.seg_selct 	= ;
	trap_gate.undefined 	= 0b00000;
	trap_gate.nul 		= 0b000;
	trap_gate.g_type	= 0b01111;
	trap_gate.dpl 		= 0b00;
	trap_gate.p 		= ;
	trap_gate.offset_e 	= ;
*/


	idtr.base = (u32)idt; 		// idt base address 
	idtr.limit = sizeof(idt); 	// idt size - 1 
	__asm__ volatile("lidt %0\r\n"
			: // no output 
			: "m" (idtr)
			: "memory");	
	//asm volatile("xchg %bx, %bx\r\n");	
}
