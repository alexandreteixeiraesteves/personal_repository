#ifndef GDTR_H
#define GDTR_H

#include <k/types.h>

struct __attribute__((packed)) gdt_r { 
	u16 limit;	// nombre d'octets dans le table 
	u32 base;	// adresse du 1er GDT de la table <=> adresse table
};

#endif /* GDTR_H */
