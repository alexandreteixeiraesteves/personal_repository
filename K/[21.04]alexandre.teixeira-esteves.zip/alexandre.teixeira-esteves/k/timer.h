#ifndef TIMER_H
#define TIMER_H

#include <k/kstd.h>
#include <k/types.h>

#include "io.h"

#define COUNT0 0x40
#define CTRL_REG 0x43 

static unsigned long tick;
static unsigned long devider;


void init_tick(void);
unsigned long gettick(void);
void update_tick(void);
	
#endif /*TIMER_H*/
