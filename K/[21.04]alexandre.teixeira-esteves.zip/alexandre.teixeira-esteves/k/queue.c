#include "queue.h"

void init_queue(void){
        queue.head = 0;
        queue.tail = 0;
        queue.size = 0;
        queue.size_max = 10;
}

int inqueue(u8 value) {
        if(queue.size == queue.size_max){
          return -1; // Queue is full!
        }
        
        queue.content[queue.tail] = value;
        
        if(queue.tail == queue.size_max - 1) {
          queue.tail = 0;
        } else {
          queue.tail += 1;
        }
        queue.size++;
        return 0;
}

int dequeue(u8 *value){
        if(queue.size == 0){
          return -1; // Queue is empty!
        }
        
        *value = queue.content[queue.head];
        
        if(queue.head == queue.size_max - 1) {
          queue.head = 0;
        } else {
          queue.head += 1;
        }
        
        queue.size--;
        return 0;
}
