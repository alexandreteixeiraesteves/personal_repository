#include "pic.h"

void init_pic(void) {
	
	
	
	//INIT ICW1
	outb(A_MSTR, 0b00010001);
	outb(A_SLVE, 0b00010001);

	//INIT ICW2
	outb(B_MSTR, 0x40);
	outb(B_SLVE, 0x50);
	
	//INIT ICW3
	outb(B_MSTR, 0b00000100);
	outb(B_SLVE, 0b00000010);
	
	//INIT ICW4 
	outb(B_MSTR, 0b00000001);
	outb(B_SLVE, 0b00000001);
	
	//INIT OCW1 // MASK for PIC
	outb(B_MSTR, 0b11111000);
	outb(B_SLVE, 0b11111111);
	
	//INIT OCW2
//	outb(A_MSTR, 0b00100000);
//	outb(A_SLVE, 0b00100000);
	
	// activation des intéruption
	asm volatile("sti\n");
	
}
