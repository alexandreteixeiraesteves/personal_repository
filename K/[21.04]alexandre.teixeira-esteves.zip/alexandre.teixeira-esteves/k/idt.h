#ifndef IDT_H
#define IDT_H

#include <k/kstd.h>
#include <k/types.h>

#include "multiboot.h"
#include "io.h"
#include "pic.h"
#include "queue.h"
#include "timer.h"

// IDT = tableau de gate (segment pour interuption)

struct __attribute__((packed)) gate {
	u16 offset_low 	:16;		// offset begin
	u16 seg_selct 	:16;		// segment selector
	u8 	: 5;			// undefined part of the gate trap & interrupt
	u8 nul 	: 3;		// offset begin
	u8 g_type 	: 5;		// gate type, part different if it is interrupt or trap gate
	u8 dpl 	: 2;		// Descriptor privilege level
	u8 p	 	: 1;		// segment present flag
	u16 offset_high :16;		// offsetend

};
 
struct __attribute__((packed)) idt_r {
	u16 limit;			// limit of the idt 
	u32 base;			// idt base adress
};

struct __attribute__((packed)) stack {
	u32 eax ;
	u32 ebx ;			// tous les registres que je push  
	u32 ecx ;
	u32 edx ;
	u32 ebp ;
	u32 esi ;
	u32 edi ;
	u32 esp ;
	u32 num_interupt;
	u32 error_code ;
};

void init_idt(void);

#endif /*IDT_H*/
