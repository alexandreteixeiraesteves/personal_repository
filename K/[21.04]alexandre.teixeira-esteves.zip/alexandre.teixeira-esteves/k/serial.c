#include "serial.h"
#include "io.h"

#include <k/types.h>

void serial_init(void) {
	outb(COM1 + 0x03, 0b00000011);		
	outb(COM1 + 0x02, 0b11000111);		
	outb(COM1 + 0x01, 0b00000010);
	outw(COM1 + 0x00, 0x03);	
	outw(COM1 + 0x01, 0x00);		
}

int write(const char* buf, size_t count)
{
	u16 lsr_add = COM1 + 0x05;
	
	for (size_t i = 0;  i < count ; i++){
		u8 lsr = inb(lsr_add);
		while((lsr & 0b00100000) != 0b00100000){
			lsr = inb(lsr_add);
		}

		outb(COM1, buf[i]);
	}

	return count;
}
