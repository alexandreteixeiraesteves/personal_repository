#ifndef SERIAL_H
#define SERIAL_H

#include <k/kstd.h>

#include "multiboot.h"

#define COM1 0x3F8
#define COM2 0x2F8
#define COM3 0x3E8
#define COM4 0x2E8

void serial_init(void);

int write(const char* buf, size_t count);

#endif /* MEMORY_H */
