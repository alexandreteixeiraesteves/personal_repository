/*
 * Copyright (c) LSE
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY LSE AS IS AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL LSE BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <k/kstd.h>

#include "multiboot.h"

#include "serial.h"
#include "gdt.h"
#include "idt.h"
#include "pic.h"
#include "queue.h"

void k_main(unsigned long magic, multiboot_info_t *info)
{
	(void)magic;
	(void)info;

	char star[4] = "|/-\\";
	char *fb = (void *)0xb8000;
	
	serial_init();
	printf("Hello\r\n");
	
	/*GDT*/
	
	init_gdt();		// init gdt & load gdtr
	//asm volatile("xchg %bx, %bx\r\n");


	asm volatile("movw $0x10, %ax\n"
              "movw %ax, %ds\r\n"
              "movw %ax, %fs\r\n"
              "movw %ax, %gs\r\n"
              "movw %ax, %ss\r\n");
	
	asm volatile("ljmp $0x08, $1f\r\n"
			"1:\r\n");


	/* IDT */
	init_idt();		// init idt & load idtr
	asm volatile("int $0");

	
	init_pic();
	//___________

	/* TEST DE LA QUEUE
	 */

	init_queue();
 
/*	// TEST QUEUE //	
	int *tmp;
	int ret = dequeue(&tmp);
	printf("-1 = %d\n", ret);

	inqueue(1);
	printf("tmp_bis is 1\n");
	inqueue(2);
	printf("tmp_bis is 2\n");
	inqueue(3);
	printf("tmp_bis is 3\n");
	inqueue(4);
	printf("tmp_bis is 4\n");
	inqueue(5);
	printf("tmp_bis is 5\n");
	inqueue(6);
	printf("tmp_bis is 6\n");
	inqueue(7);
	printf("tmp_bis is 7\n");
	inqueue(8);
	printf("tmp_bis is 8\n");
	inqueue(9);
	printf("tmp_bis is 9\n");
	inqueue(10);
	printf("tmp_bis is 10\n");
  
	dequeue(&tmp);
	printf("tmp_bis is %d\n", tmp);
	dequeue(&tmp);
	printf("tmp_bis is %d\n", tmp);
	dequeue(&tmp);
	printf("tmp_bis is %d\n", tmp);
	dequeue(&tmp);
	printf("tmp_bis is %d\n", tmp);
  
	inqueue(11);
	inqueue(12);
	inqueue(13);
	inqueue(14);
	inqueue(15);
	ret = inqueue(15);;
	printf("-1 = %d\n", ret);
*/


	
	for (unsigned i = 0; ; ) {
		*fb = star[i++ % 4];
	}

	for (;;)
 		 asm volatile ("hlt");
}	
