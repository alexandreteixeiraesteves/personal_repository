/* --- Generated the 15/4/2022 at 19:44 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 30 19:47:23 CET 2022) --- */
/* --- Command line: /home/teabis/.opam/default/bin/heptc -I /home/teabis/.opam/default/lib/heptagon/c -target c complexes.ept --- */

#ifndef COMPLEXES_TYPES_H
#define COMPLEXES_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
#include "complex_types.h"
#include "complex_io_types.h"
#endif // COMPLEXES_TYPES_H
