#ifndef SNDLIB_H
#define SNDLIB_H

void Sndlib__read_samples_step(int*sample_size,float*samples) ;
void Sndlib__write_samples_step(int*sample_size,float*samples) ;

#endif
